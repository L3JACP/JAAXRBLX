// CharacterDownloader.js
import React, { useState, useEffect } from 'react';

function CharacterDownloader() {
  const [searchQuery, setSearchQuery] = useState('');
  const [characterModels, setCharacterModels] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/characters/search?q=' + searchQuery)
      .then(response => response.json())
      .then(data => setCharacterModels(data))
      .catch(error => console.error(error));
  }, [searchQuery]);

  const handleSearch = event => {
    setSearchQuery(event.target.value);
  };

  const handleDownload = characterModelId => {
    // TO DO: implement download logic
  };

  return (
    <div>
      <input type="search" value={searchQuery} onChange={handleSearch} placeholder="Search for character models" />
      <ul>
        {characterModels.map(characterModel => (
          <li key={characterModel.id}>
            <img src={characterModel.image} alt={characterModel.name} />
            <h2>{characterModel.name}</h2>
            <button onClick={() => handleDownload(characterModel.id)}>Download</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CharacterDownloader;
